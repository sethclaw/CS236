#include "Tuple.h"
using namespace std;
Tuple::Tuple(){}
Tuple::~Tuple(){}