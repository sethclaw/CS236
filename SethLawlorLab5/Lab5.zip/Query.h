#pragma once 
#ifndef QUERY_H
#define QUERY_H
#include <vector>
#include <string>
using namespace std;

class Query : public vector<string>{};

#endif