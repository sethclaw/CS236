#pragma once
#ifndef TUPLE_H
#define TUPLE_H
#include <vector>
#include <string>
using namespace std;

class Tuple : public vector<string>{
public:
	Tuple();
	~Tuple();
};

#endif